// const video = document.querySelector("#about-video");
// if (video) {
//   let document_width = document.documentElement.clientWidth
//   if (document_width > 767 && document_width <= 1279) {
//     video.height = "410px";
//   } else if (document_width > 1279 && document_width <= 1679) {
//     video.height = "520px";
//   } else if (document_width > 1679) {
//     video.height = "100%";
//   }
// }