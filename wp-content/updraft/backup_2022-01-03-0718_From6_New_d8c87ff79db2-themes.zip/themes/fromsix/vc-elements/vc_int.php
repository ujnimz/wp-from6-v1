<?php
require get_template_directory() . '/classes/TemplateVCBuilder.php';

require get_template_directory() . '/vc-elements/vc_fromsix_heading.php';
require get_template_directory() . '/vc-elements/vc_fromsix_text_editor.php';
require get_template_directory() . '/vc-elements/vc_fromsix_button.php';
require get_template_directory() . '/vc-elements/vc_fromsix_clientele.php';
require get_template_directory() . '/vc-elements/vc_fromsix_services_grid.php';
require get_template_directory() . '/vc-elements/vc_fromsix_services_list.php';
require get_template_directory() . '/vc-elements/vc_fromsix_testimonials.php';
require get_template_directory() . '/vc-elements/vc_fromsix_posts_grid.php';
require get_template_directory() . '/vc-elements/vc_fromsix_posts_slider.php';
require get_template_directory() . '/vc-elements/vc_fromsix_blog_meta.php';
require get_template_directory() . '/vc-elements/vc_fromsix_team_grid.php';
require get_template_directory() . '/vc-elements/vc_fromsix_works_grid.php';
require get_template_directory() . '/vc-elements/vc_fromsix_counter.php';
require get_template_directory() . '/vc-elements/vc_fromsix_counter_item.php';
require get_template_directory() . '/vc-elements/vc_fromsix_images_grid.php';
require get_template_directory() . '/vc-elements/vc_fromsix_works_related.php';
require get_template_directory() . '/vc-elements/vc_fromsix_youtube_video.php';
require get_template_directory() . '/vc-elements/vc_fromsix_google_map.php';

